#ifndef SETUP_H
#define SETUP_H

#include "global.h"
#include "set_up.h"
#include "ss.h"
#include "dht.h"
#include "voltage.h"
#include "current.h"
#include "keypad.h"
#include "lcd.h"
#include "rfid.h"
#include "ui.h"
#include "GSM.h"
#include "iot.h"

void Init() {
  // put your setup code here, to run once:
  Serial.begin(9600);
  ss.begin(9600);
  lcd.begin();
  SETUP_VOLTAGE();
  SETUP_CURRENT();
  dht.dht_read(12);
  pinMode(r0, OUTPUT);
  pinMode(r1, OUTPUT);
  pinMode(r2, OUTPUT);
  pinMode(r3, OUTPUT);
  pinMode(C0, INPUT_PULLUP);
  pinMode(C1, INPUT_PULLUP);
  pinMode(C2, INPUT_PULLUP);
  pinMode(C3, INPUT_PULLUP);
  pinMode(D_BUZZER, OUTPUT);
  pinMode(D_RELAY, OUTPUT);
  digitalWrite(D_BUZZER, LOW);
  digitalWrite(D_RELAY, HIGH);
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("EV CHARGING");
  delay(1000);

}

#endif
