#ifndef DHT_H
#define DHT_H

#include "global.h"
#include"dht11.h"
DHT dht;

void Temperature() {

  dht.dht_read(12);
  dht_data = dht.temperature;
  Serial.print("dht:");
  Serial.println(dht_data);

}

#endif
