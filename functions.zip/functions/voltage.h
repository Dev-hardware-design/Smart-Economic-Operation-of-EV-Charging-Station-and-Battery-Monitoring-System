#ifndef VOLTAGE_H
#define VOLTAGE_H

#define SIGNAL_PIN A0
float adc_voltage = 0.0;
float in_voltage = 0.0;
float R1 = 30000.0;
float R2 = 7500.0;
float ref_voltage = 5.0;
int adc_value = 0;

void SETUP_VOLTAGE()
{

  pinMode(SIGNAL_PIN, INPUT);

}

void voltage_sensor() {
  adc_value = analogRead(SIGNAL_PIN);
  adc_voltage  = (adc_value * ref_voltage) / 1024.0;
  in_voltage = adc_voltage / (R2 / (R1 + R2)) ;
  Serial.print("voltage:");
  Serial.println(in_voltage);
  
}


#endif
