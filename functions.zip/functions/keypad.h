#ifndef IOTKEYPAD_H
#define IOTKEYPAD_H
#include "global.h"
volatile char key_value = 'x';

char key(void) {

  digitalWrite(r0, LOW);
  digitalWrite(r1, HIGH);
  digitalWrite(r2, HIGH);
  digitalWrite(r3, HIGH);

  if (digitalRead(C0) == LOW) {
    key_value = '1';

  }
  if (digitalRead(C1) == LOW) {
    key_value = '2';

  }
  if (digitalRead(C2) == LOW) {
    key_value = '3';

  }
  if (digitalRead(C3) == LOW) {
    key_value = 'A';

  }
  digitalWrite(r0, HIGH);
  digitalWrite(r1, LOW);
  digitalWrite(r2, HIGH);
  digitalWrite(r3, HIGH);

  if (digitalRead(C0) == LOW) {
    key_value = '4';

  }
  if (digitalRead(C1) == LOW) {
    key_value = '5';

  }
  if (digitalRead(C2) == LOW) {
    key_value = '6';

  }
  if (digitalRead(C3) == LOW) {
    key_value = 'B';

  }
  digitalWrite(r0, HIGH);
  digitalWrite(r1, HIGH);
  digitalWrite(r2, LOW);
  digitalWrite(r3, HIGH);

  if (digitalRead(C0) == LOW) {
    key_value = '7';

  }
  if (digitalRead(C1) == LOW) {
    key_value = '8';

  }
  if (digitalRead(C2) == LOW) {
    key_value = '9';

  }
  if (digitalRead(C3) == LOW) {
    key_value = 'C';

  }
  digitalWrite(r0, HIGH);
  digitalWrite(r1, HIGH);
  digitalWrite(r2, HIGH);
  digitalWrite(r3, LOW);

  if (digitalRead(C0) == LOW) {
    key_value = '*';

  }
  if (digitalRead(C1) == LOW) {
    key_value = '0';

  }
  if (digitalRead(C2) == LOW) {
    key_value = '#';
  }
  if (digitalRead(C3) == LOW) {
    key_value = 'D';
  }
  return key_value;
}
#endif
