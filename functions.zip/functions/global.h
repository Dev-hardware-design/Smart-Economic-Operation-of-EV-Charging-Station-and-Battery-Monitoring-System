#ifndef GLOBAL_H
#define GLOBAL_H

#define r0 2
#define r1 3
#define r2 4
#define r3 5
#define C0 6
#define C1 7
#define C2 8
#define C3 9
#define D_BUZZER 10
#define D_RELAY 11
#define Min 60
#define MAX_AMOUNT 3
#define RC_MAX_AMOUNT 9

/**********global variables**********/
enum
{
  HOME = 1,
  CARD_READ = 2,
  BATTERY_MONITORING = 3,
  MOBILE_RECHARGE = 4,
  PAYMENT = 5,
  CHARGING = 6
} STATES;

volatile uint8_t present_state = HOME;
volatile uint8_t previous_state = HOME;
volatile uint8_t card_amount = 0;
volatile uint8_t user_amount = 0;
volatile uint16_t time_period = 0;
int iot_count = 0;
/*******************************************/
int amount = 0;
int two_hundured = 0;
int fifty = 0;
int hundured = 0;
int dht_data;
int PERCENT;
int btry_health;
int battery_capacity = 13;
bool btry_flag, rfid_flag1, rfid_flag2, health_flag1, health_flag2, health_flag3 = false;
float Power, Internal_Resistance;

#endif
