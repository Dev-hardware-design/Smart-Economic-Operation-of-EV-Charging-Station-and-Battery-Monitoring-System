#ifndef GSM_H
#define GSM_H
void send_sms(String number, String balance, String debited);
void send_sms(String number, String balance, String debited)
{

  Serial.println();
  Serial.println("AT");
  delay(1000);
  Serial.println("AT+CMGF=1");
  delay(1000);
  Serial.println("AT+CMGS=\"+91" + number + "\"\r");
  delay(1000);
  Serial.println("DEBITED AMOUNT");
  delay(200);
  Serial.println(debited + "/-");
  delay(200);
  Serial.println("BALANCE AMOUNT");
  delay(200);
  Serial.println(balance + "/-");
  delay(200);
  Serial.println(char(26));
}
#endif
