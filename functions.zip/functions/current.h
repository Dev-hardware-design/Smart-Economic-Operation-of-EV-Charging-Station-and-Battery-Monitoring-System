#ifndef CURRENT_H
#define CURRENT_H

#include "ACS712.h"
float I = 0.0;
ACS712 sensor(ACS712_30A, A1);

void SETUP_CURRENT() {

  sensor.calibrate();
}

void CURRENT() {

  float U = 230;
  I = sensor.getCurrentAC();
  Serial.print("current:");
  Serial.println(I);

}


#endif
