#ifndef UI_H
#define UI_H

#include "global.h"
#include "eeprom.h"
#include "set_up.h"
#include "ss.h"
#include "dht.h"
#include "voltage.h"
#include "current.h"
#include "keypad.h"
#include "lcd.h"
#include "rfid.h"
#include "ui.h"
#include "GSM.h"
#include "iot.h"

void home_screen();
void recharge(void);
int total = 0;

void card()
{
  switch (present_state)
  {
    case HOME:
      {
        digitalWrite(D_BUZZER, LOW);
        card_amount = 0;
        rfidno = 0;
        key_value = 'x';
        lcd.clear();
        lcd.setCursor(0, 0);
        lcd.print("1.CARD CHARGING");
        lcd.setCursor(0, 1);
        lcd.print("2.BTRY MONTRNG ");
        if (key() == '1')
        {
          present_state = CARD_READ;
        }
        if (key() == '2')
        {
          present_state = BATTERY_MONITORING;
        }
      }
      break;

    case CARD_READ:
      {
        digitalWrite(D_BUZZER, LOW);
        if (rfid() != 0)
        {
          if (rfid_flag1 == true) {
            if (rfidno == 1) {
              rfid_flag1 = false;
              lcd.clear();
              lcd.setCursor(0, 0);
              lcd.print("  DEV ADHITHYA  ");
              lcd.setCursor(0, 1);
              lcd.print("  8700850A1911  ");
            }
          }
          if (rfid_flag2 == true) {
            if (rfidno == 2) {
              rfid_flag2 = false;
              lcd.clear();
              lcd.setCursor(0, 0);
              lcd.print("   AJAI KUMAR   ");
              lcd.setCursor(0, 1);
              lcd.print("  8700855C4816  ");
            }
          }
          delay(3000);
          card_amount = EEPROM.read(rfid());
          lcd.clear();
          lcd.setCursor(0, 0);
          lcd.print("BAL:");
          lcd.setCursor(4, 0);
          lcd.print(card_amount * 100);
          lcd.setCursor(10, 0);
          lcd.print("EXIT:0");
          lcd.setCursor(0, 1);
          lcd.print("CHRGE:*");
          lcd.setCursor(8, 1);
          lcd.print("RECHRG:#");
        }
        else
        {
          lcd.clear();
          lcd.setCursor(0, 0);
          lcd.print("READING ID.... ");
          rfidno = 0;
        }
        switch (key())
        {
          case '#':
            key_value = 'x';
            present_state = MOBILE_RECHARGE;
            previous_state = CARD_READ;
            break;

          case '0':
            key_value = 'x';
            rfidno = 0;
            card_amount = 0;
            present_state = HOME;
            previous_state = HOME;
            break;

          case '*':
            key_value = 'x';
            present_state = CHARGING;
            previous_state = PAYMENT;
            break;
        }
        break;
      }
    case BATTERY_MONITORING:
      {
        voltage_sensor();
        CURRENT();
        PERCENT = (in_voltage / battery_capacity) * 100;
        Power = in_voltage * I;
        Serial.print("power:");
        Serial.println(Power);
        Internal_Resistance = (in_voltage / I) - 0.4;
        lcd.clear();
        lcd.setCursor(0, 0);
        lcd.print("SoC:");
        lcd.setCursor(4, 0);
        lcd.print(PERCENT);
        lcd.print("%");
        lcd.setCursor(0, 1);
        lcd.print("EXT:");
        lcd.print("0");
        lcd.setCursor(8, 0);
        lcd.print("SoP:");
        lcd.print(Power);
        lcd.setCursor(7, 1);
        lcd.print(" IR:");
        lcd.print(Internal_Resistance);

        if (in_voltage <= 9)
        {
          btry_flag = true;
        }
        if ((btry_flag == true) && (in_voltage > 9))
        {
          btry_flag = false;
          health_flag1 = true;
          health_flag2 = true;
          health_flag3 = true;
          btry_health++;
        }
        if ((health_flag1 == true) && (btry_health == 1)) {
          health_flag1 = false;
          lcd.clear();
          lcd.setCursor(0, 1);
          lcd.print("BTRY HEALTH HIGH");
        }

        if ((health_flag2 == true) && (btry_health == 2)) {
          health_flag2 = false;
          lcd.clear();
          lcd.setCursor(0, 1);
          lcd.print("BTRY HEALTH NRML");
        }

        if ((health_flag3 == true) && (btry_health == 3)) {
          health_flag3 = false;
          lcd.clear();
          btry_health = 0;
          lcd.setCursor(0, 1);
          lcd.print("BTRY HEALTH LOW ");
        }

        if (key() == '0') {
          present_state = HOME;
        }
        iot_send("@" + String(in_voltage) + "#" + "$" + String(I) + "#" + "^" + String(PERCENT) + "#" + "&" + String(Power) + "#" + "!" + String(Internal_Resistance) + "#");
        break;
      }
    case MOBILE_RECHARGE:
      {
        lcd.clear();
        lcd.setCursor(0, 0);
        lcd.print("   RECHARGE:A   ");
        lcd.setCursor(10, 1);
        lcd.print("EXIT:D");
        lcd.setCursor(0, 1);
        lcd.print("RESET:B");
        switch (key())
        {
          case 'A':
            key_value = 'x';
            recharge();
            break;
          case 'B':
            key_value = 'x';
            eeprom_clear();
            card_amount = EEPROM.read(rfid());
            present_state = HOME;
            previous_state = HOME;
            break;
          case 'D':
            key_value = 'x';
            present_state = CARD_READ;
            previous_state = HOME;
            break;
        }
        break;
      }
    case CHARGING:
      {
        switch (previous_state)
        {
          case PAYMENT:
            {
              switch (key())
              {
                case '1':
                  key_value = 'x';
                  user_amount = 1;
                  break;
                case '2':
                  key_value = 'x';
                  user_amount = 2;
                  break;
                case '3':
                  key_value = 'x';
                  user_amount = 3;
                  break;
              }
              time_period = Min * user_amount;
              lcd.clear();
              lcd.setCursor(0, 0);
              lcd.print("CHS AMT:");
              lcd.setCursor(10, 0);
              lcd.print("1.100");
              lcd.setCursor(0, 1);
              lcd.print("2.200");
              lcd.setCursor(6, 1);
              lcd.print("3.300");
              if (user_amount > card_amount)
              {
                user_amount = 0;
                lcd.clear();
                lcd.setCursor(0, 0);
                lcd.print("PLS RECHARGE OR");
                lcd.setCursor(0, 1);
                lcd.print("ENTER VALID AMT");
                //iot_send("*PLS RECHARGE OR ENTER VALID AMT#");
                present_state = CARD_READ;
              }
              else if (user_amount != 0 && user_amount <= card_amount)
              {
                user_amount = 0;
                present_state = CHARGING;
                previous_state = CARD_READ;
              }
              break;
            }

          case CARD_READ:
            {
              if ((time_period == 0) || (key() == '8'))
              {
                lcd.clear();
                lcd.setCursor(0, 0);
                lcd.print("THANK YOU...                 ");
                digitalWrite(D_RELAY, HIGH);
                EEPROM.write(rfid(), card_amount);
                time_period = 0;

                for (int i = 0; i < 5; i++)
                {
                  digitalWrite(D_BUZZER, HIGH);
                  delay(150);
                  digitalWrite(D_BUZZER, LOW);
                  delay(150);
                }
                send_sms("9941200687", String(card_amount * 100), String(rfid() * 100));
                iot_send("%" + String(card_amount*100) + "#");
                present_state = HOME;
              }
              else if (time_period != 0 )
              {
                lcd.clear();
                lcd.setCursor(0, 0);
                lcd.print("SLOT:");
                lcd.setCursor(15, 0);
                lcd.print("S");
                lcd.setCursor(0, 1);
                lcd.print("AMT:");
                lcd.setCursor(10, 1);
                lcd.print("8-STOP");
                digitalWrite(D_RELAY, LOW);
                lcd.setCursor(5, 0);
                lcd.print("ON");
              }
              if ((time_period % 60) == 0)
              {
                card_amount--;
              }
              time_period--;
              lcd.setCursor(11, 0);
              lcd.print(time_period);
              lcd.setCursor(4, 1);
              lcd.print(card_amount * 100);

              if (dht_data > 33) {
                digitalWrite(D_RELAY, HIGH);
                lcd.clear();
                lcd.setCursor(0, 0);
                lcd.print(" CHARGING STOP  ");
                lcd.setCursor(0, 1);
                lcd.print("HIGH TEMPERATURE");
                for (int i = 0; i < 5; i++)
                {
                  digitalWrite(D_BUZZER, HIGH);
                  delay(75);
                  digitalWrite(D_BUZZER, LOW);
                  delay(75);
                }
                iot_send("~" + String(dht_data) + "#");
                delay(500);
                present_state = HOME;
              }
            }
            break;
        }
      }
      break;
  }
}

void recharge(void)
{
  int temp = EEPROM.read(rfid());
  temp = temp + MAX_AMOUNT;
  lcd.clear();
  if (temp <= RC_MAX_AMOUNT)
  {
    EEPROM.write(rfid(), temp);
    lcd.setCursor(0, 0);
    lcd.print("RC SUCCESS..");
  }
  else
  {
    lcd.setCursor(0, 0);
    lcd.print("RC LIMIT REACHED..");
  }
  present_state = CARD_READ;
}

#endif
